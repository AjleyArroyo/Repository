@extends('app')

@section('content')





	<div class="content">
		<div class="container-fluid">
			<center>
				<div class="col-sm-4 col-sm-offset-4" style="height: 250px">
				<p class="text-center"style="margin-top: 90px;font-size: 50px">Bienvenido</p>
				</div>
			</center>
		</div>
	</div>





@endsection
